# HTML-CSS-ProductCard

<img width="741" alt="Screenshot 2022-10-02 at 17 25 50" src="https://user-images.githubusercontent.com/42389395/193465061-2d4e3916-feed-4568-a90a-804e9cf2583d.png">
